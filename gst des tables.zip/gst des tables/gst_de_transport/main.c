#include <stdio.h>
#include <string.h>

typedef struct {
    char nom[50];
    char horaires[10][10];
    int nombreHoraires;
} Arret;

typedef struct {
    char nom[50];
    Arret arrets[100];
    int nombreArrets;
} Ligne;

typedef struct {
    Ligne lignes[10];
    int nombreLignes;
} ReseauTransport;

ReseauTransport reseau;

// Ajouter une ligne
void ajouterLigne() {
    if (reseau.nombreLignes < 10) {
        printf("Nom de la ligne : ");
        scanf(" %49s", reseau.lignes[reseau.nombreLignes].nom);
        reseau.lignes[reseau.nombreLignes].nombreArrets = 0;
        reseau.nombreLignes++;
        printf("Ligne ajoutee.\n");
    } else {
        printf("Limite de lignes atteinte.\n");
    }
}

// Ajouter un arr�t � une ligne
void ajouterArret() {
    char nomLigne[50];
    printf("Nom de la ligne : ");
    scanf(" %49s", nomLigne);

    for (int i = 0; i < reseau.nombreLignes; i++) {
        if (strcmp(reseau.lignes[i].nom, nomLigne) == 0) {
            if (reseau.lignes[i].nombreArrets < 100) {
                printf("Nom de l'arret : ");
                scanf(" %49s", reseau.lignes[i].arrets[reseau.lignes[i].nombreArrets].nom);

                printf("Nombre d'horaires pour cet arret : ");
                int nombreHoraires;
                scanf("%d", &nombreHoraires);

                reseau.lignes[i].arrets[reseau.lignes[i].nombreArrets].nombreHoraires = nombreHoraires;
                for (int j = 0; j < nombreHoraires; j++) {
                    printf("Horaire %d (HH:MM) : ", j + 1);
                    scanf(" %9s", reseau.lignes[i].arrets[reseau.lignes[i].nombreArrets].horaires[j]);
                }

                reseau.lignes[i].nombreArrets++;
                printf("Arret ajoute.\n");
            } else {
                printf("Limite d'arrets atteinte pour cette ligne.\n");
            }
            return;
        }
    }
    printf("Ligne non trouvee.\n");
}

// Afficher les lignes et les arr�ts
void afficherLignes() {
    if (reseau.nombreLignes == 0) {
        printf("Aucune ligne disponible.\n");
        return;
    }

    for (int i = 0; i < reseau.nombreLignes; i++) {
        printf("Ligne : %s\n", reseau.lignes[i].nom);
        for (int j = 0; j < reseau.lignes[i].nombreArrets; j++) {
            printf("  Arret : %s | Horaires : ", reseau.lignes[i].arrets[j].nom);
            for (int k = 0; k < reseau.lignes[i].arrets[j].nombreHoraires; k++) {
                printf("%s ", reseau.lignes[i].arrets[j].horaires[k]);
            }
            printf("\n");
        }
    }
}

// Recherche d'itin�raire entre deux arr�ts sur la m�me ligne
void rechercherItineraire() {
    char ligneRecherchee[50], arretDepart[50], arretArrivee[50];
    printf("Nom de la ligne : ");
    scanf(" %49s", ligneRecherchee);

    for (int i = 0; i < reseau.nombreLignes; i++) {
        if (strcmp(reseau.lignes[i].nom, ligneRecherchee) == 0) {
            printf("Arret de depart : ");
            scanf(" %49s", arretDepart);

            printf("Arret d'arrivee : ");
            scanf(" %49s", arretArrivee);

            int indexDepart = -1, indexArrivee = -1;
            for (int j = 0; j < reseau.lignes[i].nombreArrets; j++) {
                if (strcmp(reseau.lignes[i].arrets[j].nom, arretDepart) == 0) indexDepart = j;
                if (strcmp(reseau.lignes[i].arrets[j].nom, arretArrivee) == 0) indexArrivee = j;
            }

            if (indexDepart != -1 && indexArrivee != -1 && indexDepart <= indexArrivee) {
                printf("Itin�raire : ");
                for (int j = indexDepart; j <= indexArrivee; j++) {
                    printf("%s ", reseau.lignes[i].arrets[j].nom);
                }
                printf("\n");
            } else {
                printf("Itineraire impossible.\n");
            }
            return;
        }
    }
    printf("Ligne non trouvee.\n");
}

// Sauvegarder les donn�es dans un fichier
void sauvegarder() {
    FILE *fichier = fopen("reseau.txt", "w");
    if (fichier == NULL) {
        printf("Erreur lors de la sauvegarde.\n");
        return;
    }

    fprintf(fichier, "%d\n", reseau.nombreLignes);
    for (int i = 0; i < reseau.nombreLignes; i++) {
        fprintf(fichier, "%s %d\n", reseau.lignes[i].nom, reseau.lignes[i].nombreArrets);
        for (int j = 0; j < reseau.lignes[i].nombreArrets; j++) {
            fprintf(fichier, "%s %d ", reseau.lignes[i].arrets[j].nom, reseau.lignes[i].arrets[j].nombreHoraires);
            for (int k = 0; k < reseau.lignes[i].arrets[j].nombreHoraires; k++) {
                fprintf(fichier, "%s ", reseau.lignes[i].arrets[j].horaires[k]);
            }
            fprintf(fichier, "\n");
        }
    }
    fclose(fichier);
    printf("Donn�es sauvegardees.\n");
}

// Charger les donn�es depuis un fichier
void charger() {
    FILE *fichier = fopen("reseau.txt", "r");
    if (fichier == NULL) {
        printf("Aucune sauvegarde trouvee.\n");
        return;
    }

    fscanf(fichier, "%d", &reseau.nombreLignes);
    for (int i = 0; i < reseau.nombreLignes; i++) {
        fscanf(fichier, " %49s %d", reseau.lignes[i].nom, &reseau.lignes[i].nombreArrets);
        for (int j = 0; j < reseau.lignes[i].nombreArrets; j++) {
            fscanf(fichier, " %49s %d", reseau.lignes[i].arrets[j].nom, &reseau.lignes[i].arrets[j].nombreHoraires);
            for (int k = 0; k < reseau.lignes[i].arrets[j].nombreHoraires; k++) {
                fscanf(fichier, " %9s", reseau.lignes[i].arrets[j].horaires[k]);
            }
        }
    }
    fclose(fichier);
    printf("Donn�es chargees.\n");
}

// Menu principal
void menu() {
    int choix;
    do {
        printf("\n1. Ajouter une ligne\n2. Ajouter un arret\n3. Afficher les lignes\n4. Rechercher un itineraire\n5. Sauvegarder\n6. Charger\n0. Quitter\nChoix : ");
        scanf("%d", &choix);

        if (choix == 1) ajouterLigne();
        else if (choix == 2) ajouterArret();
        else if (choix == 3) afficherLignes();
        else if (choix == 4) rechercherItineraire();
        else if (choix == 5) sauvegarder();
        else if (choix == 6) charger();
    } while (choix != 0);
}

int main() {
    reseau.nombreLignes = 0;
    menu();
    return 0;
}
